/** 按项目批量入队角色/场景/道具参考图（只走已有生图接口，不注册外部账号） */
import { api, type BillingPreflight } from '../api'
import { dramaApi, type DramaAsset, type DramaProject } from '../api/drama'
import { handleBillingError, isBillingError } from './billingError'
import { dialog } from './dialog'
import { dramaAssetNeedsImageGeneration } from './dramaAssetImage'
import {
  defaultOptionsForAssetKind,
  type ImageGenerationOptions,
} from './dramaGenerationOptions'
import { enqueueDramaImageGen, isDramaAssetImageBusy } from './dramaImageGenQueue'
import { filterDramaLibraryAssets } from './dramaLibraryAssets'
import { readVisualPrompt } from './dramaVisualPrompt'

export type BatchAssetImageResult = {
  queued: number
  skipped: number
  cancelled: boolean
}

function imageStyleIdOf(project: DramaProject | null): string {
  const fromScript = (project?.script?.params || {}).image_style_id
  const fromProject = (project?.params || {}).image_style_id
  return String(fromScript || fromProject || '')
}

function isVisualLibraryAsset(asset: DramaAsset): boolean {
  const kind = (asset.type || '').toLowerCase()
  return kind === 'character' || kind === 'scene' || kind === 'prop'
}

async function ensureImageGenBalance(count: number): Promise<BillingPreflight | null> {
  try {
    return await api.billingPreflight({
      domain: 'drama',
      task_type: 'asset_image',
      count,
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err || '')
    if (isBillingError(message)) return null
    if (await handleBillingError(err)) return null
    throw err instanceof Error ? err : new Error(message || '余额校验失败')
  }
}

async function loadVisualAssets(projectId: number, project: DramaProject | null): Promise<DramaAsset[]> {
  let list = filterDramaLibraryAssets(
    await dramaApi.listAssets(projectId, { libraryOnly: true }),
  ).filter(isVisualLibraryAsset)
  if (list.length === 0 && project?.script?.summary) {
    const seeded = await dramaApi.seedAssets(projectId)
    list = filterDramaLibraryAssets(seeded?.assets || []).filter(isVisualLibraryAsset)
    if (list.length === 0) {
      list = filterDramaLibraryAssets(
        await dramaApi.listAssets(projectId, { libraryOnly: true }),
      ).filter(isVisualLibraryAsset)
    }
  }
  return list
}

export async function enqueueProjectAssetImages(opts: {
  projectId: number
  /** 已有图也重新生成 */
  forceRegen?: boolean
  title: string
  confirmVerb: string
  onAssetUpdate?: (asset: DramaAsset) => void
}): Promise<BatchAssetImageResult> {
  const project = await dramaApi.getProject(opts.projectId)
  const assets = await loadVisualAssets(opts.projectId, project)
  const idle = assets.filter((asset) => !isDramaAssetImageBusy(asset.id))
  const missing = idle.filter((asset) => dramaAssetNeedsImageGeneration(asset))
  let targets = opts.forceRegen ? idle : missing

  if (!opts.forceRegen && missing.length === 0 && idle.length > 0) {
    const regen = await dialog.confirm({
      title: opts.title,
      message: `「${project.title}」的 ${idle.length} 个视觉资产都已有参考图。是否全部重新生成？`,
      confirmText: '全部重新生成',
    })
    if (!regen) return { queued: 0, skipped: assets.length, cancelled: true }
    targets = idle
  }

  if (targets.length === 0) {
    throw new Error(assets.length === 0 ? '该项目还没有可生成的角色/场景/道具' : '没有可生成的资产（可能都在生成中）')
  }

  const pre = await ensureImageGenBalance(targets.length)
  if (!pre) return { queued: 0, skipped: assets.length, cancelled: true }

  const unitYuan = pre.unit_estimate_yuan ?? pre.unit_estimate_fen / 100
  const totalYuan = pre.requested_total_yuan ?? pre.requested_total_fen / 100
  const balanceYuan = pre.balance_yuan ?? pre.balance_fen / 100
  const ok = await dialog.confirm({
    title: opts.title,
    message:
      `将为「${project.title}」入队 ${targets.length} 个资产参考图（角色/场景/道具，并行提交）。\n\n` +
      `每张预扣约 ¥${unitYuan.toFixed(2)}，本次合计约 ¥${totalYuan.toFixed(2)}（当前余额 ¥${balanceYuan.toFixed(2)}；结束后按实际上游用量多退少补）。\n\n是否${opts.confirmVerb}？`,
    confirmText: opts.confirmVerb,
  })
  if (!ok) return { queued: 0, skipped: assets.length, cancelled: true }

  const styleId = imageStyleIdOf(project)
  const tasks = targets.map((asset) =>
    enqueueDramaImageGen({
      projectId: opts.projectId,
      assetId: asset.id,
      assetName: asset.name || undefined,
      assetType: asset.type,
      prompt: readVisualPrompt(asset),
      options: {
        ...defaultOptionsForAssetKind(asset.type),
        image_style_id: styleId || undefined,
      } satisfies Partial<ImageGenerationOptions>,
      onAssetUpdate: opts.onAssetUpdate,
    }),
  )
  const results = await Promise.allSettled(tasks)
  const failed = results.find((row) => row.status === 'rejected')
  if (failed && failed.status === 'rejected') {
    throw failed.reason instanceof Error ? failed.reason : new Error(String(failed.reason || '入队失败'))
  }
  return { queued: targets.length, skipped: assets.length - targets.length, cancelled: false }
}
